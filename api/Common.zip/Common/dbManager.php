<?php

  function getRootConnection(){
    $host = "localhost";
    $db_name = "zirconia";
    $username = "root";
    $password = "";

    $connection = new PDO("mysql:host=" . $host . ";dbname=" . $db_name, $username, $password);
    return $connection;
  }

  function getUserConnection($logintoken) {
    $host = "localhost";
    $db = getRootConnection();
    $query = "SELECT clinics.id,clinics.validuntil,clinics.dbname,clinics.dbuser,clinics.dbpass
              ,users.clinicid,users.isactive,users.logintoken FROM users LEFT JOIN clinics ON users.clinicid = clinics.id
              HAVING users.logintoken = :logintoken AND users.isactive = 1 AND clinics.validuntil > CURRENT_DATE()";
    $sql = $db->prepare($query);
    $sql->bindValue(":logintoken", $logintoken);
    if($sql->execute() && $sql->rowCount() > 0) {
      $row = $sql->fetch(PDO::FETCH_ASSOC);
      extract($row);
      $connection = new PDO("mysql:host=" . $host . ";dbname=" . $dbname, $dbuser, $dbpass);
      return $connection;
    }
    else {
      return "";
    }
  }

  function checkToken($token) {
    return $token == 'abc';
  }

  function checkConnectionAuthorized($token) {
    return $_SERVER['REQUEST_METHOD'] == 'POST' && $token != "" && checkToken($token);
  }

  function checkUserIsActive($db) {
    return $db != "";
  }

  function checkRequiredFields($a='a',$b='b',$c='c',$d='d',$e='e',$f='f',$g='g',$h='h',) {
    return $a != '' && $b != '' && $c != '' && $d != '' && $e != '' && $f != '' && $g != '' && $h != '';
  }

  function checkDateFormat($string) {
    if ($string <> "" && strtotime($string)) return true;
    else return false;
  }
  
?>