<?php
  include('../Common/headers.php');
  include ('../Common/dbManager.php');
  sleep(1);
  $props = json_decode(file_get_contents("php://input"),true);
  $token = isset($props['token']) ? $props['token'] : '';
  $username = isset($props['username']) ? $props['username'] : '';
  $password = isset($props['password']) ? $props['password'] : '';
  
  $result_arr=array();
  $result_arr["result"]=0;
  $result_arr["message"]="حدث خطأ في الإتصال" ;

  if(checkConnectionAuthorized($token)) {
    if(checkRequiredFields($username,$password)) {

      $db = getRootConnection();
      $sql = $db->prepare(
        "SELECT logintoken FROM users 
         WHERE username=:username AND userpassword=:userpassword AND isactive = 1 AND
          clinicid in (select id from clinics where validuntil > CURRENT_DATE())"
      );
      $sql->bindValue(":username", $username);
      $sql->bindValue(":userpassword", $password);
      if($sql->execute() && $sql->rowCount() > 0) {
        $result_arr["result"]=1;
        $result_arr["message"]="Success";
        $row = $sql->fetch(PDO::FETCH_ASSOC);
        extract($row);
        $result_arr["logintoken"]=$logintoken;
      }
      else {
        $result_arr["message"] = "بيانات المستخدم الحالي غير صالحة, يرحى التأكد من صلاحية الإشتراك" ;
      }
    }
    else {
      $result_arr["message"]="يرجى إدخال إسم المستخدم وكلمة المرور";
    }
  }

  echo json_encode($result_arr);
?>